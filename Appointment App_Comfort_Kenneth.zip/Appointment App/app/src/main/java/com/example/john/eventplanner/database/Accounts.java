package com.example.john.eventplanner.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.example.john.eventplanner.core.Constants;
import com.example.john.eventplanner.core.DBHelper;

import static com.example.john.eventplanner.core.Constants.config.ACCOUNT_AMOUNT;
import static com.example.john.eventplanner.core.Constants.config.ACCOUNT_DATE;
import static com.example.john.eventplanner.core.Constants.config.ACCOUNT_DESCRIPTION;
import static com.example.john.eventplanner.core.Constants.config.ACCOUNT_ID;
import static com.example.john.eventplanner.core.Constants.config.ACCOUNT_NAME;
import static com.example.john.eventplanner.core.Constants.config.ACCOUNT_STATUS;
import static com.example.john.eventplanner.core.Constants.config.ACCOUNT_TIME;
import static com.example.john.eventplanner.core.Constants.config.ACCOUNT_TYPE;
import static com.example.john.eventplanner.core.Constants.config.EVENT_ID;

/**
 * Created by john on 2/18/19.
 */

public class Accounts {
    private Context context;
    private static final String TAG = "User";
    public Accounts(Context context){
        this.context = context;
    }

    public String save(String account_name, String account_descriptions, String account_date, String account_time, String account_amount, int account_type, int account_status, int event_id){
        SQLiteDatabase database = DBHelper.getHelper(context).getWritableDatabase();
        String message = null;
        try{
            database.beginTransactionNonExclusive();
            ContentValues contentValues = new ContentValues();
            contentValues.put(ACCOUNT_NAME,account_name);
            contentValues.put(ACCOUNT_DESCRIPTION,account_descriptions);
            contentValues.put(ACCOUNT_AMOUNT,account_amount);
            contentValues.put(ACCOUNT_DATE,account_date);
            contentValues.put(ACCOUNT_TIME,account_time);
            contentValues.put(ACCOUNT_TYPE,account_type);
            contentValues.put(ACCOUNT_STATUS,account_status);
            contentValues.put(EVENT_ID,event_id);
            database.insert(Constants.config.TABLE_ACCOUNT, null, contentValues);
            database.setTransactionSuccessful();
            message = "Account Details saved!";
        }catch (Exception e){
            e.printStackTrace();
            message = "Sorry, error: "+e;
        }finally {
            database.endTransaction();
        }
        return message;
    }

    public String update(int account_id,String account_name, String account_descriptions, String account_date, String account_time, String account_amount, int account_type, int account_status, int event_id){
        SQLiteDatabase database = DBHelper.getHelper(context).getWritableDatabase();
        String message = null;
        try{
            database.beginTransactionNonExclusive();
            ContentValues contentValues = new ContentValues();
            contentValues.put(ACCOUNT_NAME,account_name);
            contentValues.put(ACCOUNT_DESCRIPTION,account_descriptions);
            contentValues.put(ACCOUNT_AMOUNT,account_amount);
            contentValues.put(ACCOUNT_DATE,account_date);
            contentValues.put(ACCOUNT_TIME,account_time);
            contentValues.put(ACCOUNT_TYPE,account_type);
            contentValues.put(ACCOUNT_STATUS,account_status);
            contentValues.put(EVENT_ID,event_id);
            database.update(Constants.config.TABLE_ACCOUNT,  contentValues, ACCOUNT_ID+" = "+account_id, null);
            database.setTransactionSuccessful();
            message = "Account updated!";
        }catch (Exception e){
            e.printStackTrace();
            message = "Sorry, error: "+e;
        }finally {
            database.endTransaction();
        }

        return message;
    }

    public String updateStatus(int account_id,int account_status){
        SQLiteDatabase database = DBHelper.getHelper(context).getWritableDatabase();
        String message = null;
        try{
            database.beginTransactionNonExclusive();
            ContentValues contentValues = new ContentValues();
            contentValues.put(ACCOUNT_STATUS,account_status);
            database.update(Constants.config.TABLE_ACCOUNT,  contentValues, ACCOUNT_ID+" = "+account_id, null);
            database.setTransactionSuccessful();
            message = "Event updated!";
        }catch (Exception e){
            e.printStackTrace();
            message = "Sorry, error: "+e;
        }finally {
            database.endTransaction();
        }

        return message;
    }
}
