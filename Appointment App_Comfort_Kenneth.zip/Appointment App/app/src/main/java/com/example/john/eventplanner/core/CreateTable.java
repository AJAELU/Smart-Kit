package com.example.john.eventplanner.core;

/**
 * Created by john on 10/20/17.
 */

public class CreateTable {
    public abstract class config{

        public  static  final String CREATE_EVENT =
                "CREATE TABLE "+ Constants.config.TABLE_EVENT +" ("+ Constants.config.EVENT_ID+" INTEGER PRIMARY KEY AUTOINCREMENT," +
                        " "+ Constants.config.EVENT_TITLE+" TEXT,"+ Constants.config.EVENT_DESCRIPTIONS+" TEXT, "+ Constants.config.EVENT_DATE+" TEXT," +
                        " "+ Constants.config.EVENT_ADDRESS+" TEXT,"+Constants.config.EVENT_STATUS+" INTEGER);";

        public  static  final String CREATE_MEMBER =
                "CREATE TABLE "+ Constants.config.TABLE_MEMBER +" ("+ Constants.config.MEMBER_ID+" INTEGER PRIMARY KEY AUTOINCREMENT," +
                        " "+ Constants.config.MEMBER_NAME+" TEXT,"+ Constants.config.MEMBER_PHONE+" TEXT, "+Constants.config.MEMBER_EMAIL+" TEXT, " +
                        " "+Constants.config.MEMBER_ADDRESS+" TEXT,"+Constants.config.MEMBER_GENDER+" TEXT, "+Constants.config.MEMBER_ROLE+" TEXT," +
                        " "+Constants.config.EVENT_ID+" INTEGER,"+Constants.config.MEMBER_STATUS+" INTEGER);";

        public  static  final String CREATE_GUEST =
                "CREATE TABLE "+ Constants.config.TABLE_GUEST +" ("+ Constants.config.GUEST_ID+" INTEGER PRIMARY KEY AUTOINCREMENT," +
                        " "+ Constants.config.GUEST_NAME+" TEXT,"+ Constants.config.GUEST_PHONE+" TEXT, "+Constants.config.GUEST_EMAIL+" TEXT, " +
                        " "+Constants.config.GUEST_ADDRESS+" TEXT,"+Constants.config.GUEST_GENDER+" TEXT, "+Constants.config.GUEST_TYPE+" TEXT," +
                        " "+Constants.config.EVENT_ID+" INTEGER,"+Constants.config.GUEST_STATUS+" INTEGER);";

        public  static  final String CREATE_SHOPPING =
                "CREATE TABLE "+ Constants.config.TABLE_SHOPPING +" ("+ Constants.config.SHOPPING_ID+" INTEGER PRIMARY KEY AUTOINCREMENT," +
                        " "+ Constants.config.SHOPPING_NAME+" TEXT,"+ Constants.config.SHOPPING_DESCRIPTION+" TEXT, "+ Constants.config.SHOPPING_AMOUNT+" TEXT," +
                        " "+ Constants.config.SHOPPING_DATE+" TEXT,"+ Constants.config.SHOPPING_TIME+" TEXT,"+Constants.config.SHOPPING_STATUS+" INTEGER, " +
                        " "+ Constants.config.EVENT_ID+" INTEGER);";

        public  static  final String CREATE_INVITATION =
                "CREATE TABLE "+ Constants.config.TABLE_INVITATION +" ("+ Constants.config.INVITATION_ID+" INTEGER PRIMARY KEY AUTOINCREMENT," +
                        " "+ Constants.config.INVITATION_DATE+" TEXT,"+ Constants.config.INVITATION_TIME+" TEXT, "+ Constants.config.INVITATION_STATUS+" INTEGER," +
                        " "+Constants.config.GUEST_ID+" INTEGER);";


        public  static  final String CREATE_ACCOUNT =
                "CREATE TABLE "+ Constants.config.TABLE_ACCOUNT +" ("+ Constants.config.ACCOUNT_ID+" INTEGER PRIMARY KEY AUTOINCREMENT," +
                        " "+ Constants.config.ACCOUNT_NAME+" TEXT,"+ Constants.config.ACCOUNT_AMOUNT+" TEXT, "+ Constants.config.ACCOUNT_DATE+" TEXT," +
                        " "+ Constants.config.ACCOUNT_TIME+" TEXT,"+ Constants.config.ACCOUNT_DESCRIPTION+" TEXT,"+Constants.config.ACCOUNT_STATUS+" INTEGER, " +
                        " "+ Constants.config.ACCOUNT_TYPE+" INTEGER, "+Constants.config.EVENT_ID+" INTEGER);";

        public  static  final String CREATE_TODO =
                "CREATE TABLE "+ Constants.config.TABLE_TODO +" ("+ Constants.config.TODO_ID+" INTEGER PRIMARY KEY AUTOINCREMENT," +
                        " "+ Constants.config.TODO_TITLE+" TEXT,"+ Constants.config.TODO_DESC+" TEXT, "+ Constants.config.TODO_DATE+" TEXT," +
                        " "+ Constants.config.TODO_TIME+" TEXT,"+ Constants.config.TODO_STATUS+" INTEGER,"+Constants.config.EVENT_ID+" INTEGER);";
    }
}
