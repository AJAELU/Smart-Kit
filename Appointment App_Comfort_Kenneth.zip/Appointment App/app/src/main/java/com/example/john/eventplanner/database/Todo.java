package com.example.john.eventplanner.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import com.example.john.eventplanner.core.Constants;
import com.example.john.eventplanner.core.DBHelper;
import static com.example.john.eventplanner.core.Constants.config.EVENT_ID;
import static com.example.john.eventplanner.core.Constants.config.TODO_DATE;
import static com.example.john.eventplanner.core.Constants.config.TODO_DESC;
import static com.example.john.eventplanner.core.Constants.config.TODO_ID;
import static com.example.john.eventplanner.core.Constants.config.TODO_STATUS;
import static com.example.john.eventplanner.core.Constants.config.TODO_TIME;
import static com.example.john.eventplanner.core.Constants.config.TODO_TITLE;

/**
 * Created by john on 2/19/19.
 */

public class Todo {
    private Context context;
    private static final String TAG = "User";
    public Todo(Context context){
        this.context = context;
    }

    public String save(String todo_title, String todo_desc, String todo_date, String todo_time, int todo_status,int event_id){
        SQLiteDatabase database = DBHelper.getHelper(context).getWritableDatabase();
        String message = null;
        try{
            database.beginTransactionNonExclusive();
            ContentValues contentValues = new ContentValues();
            contentValues.put(TODO_TITLE,todo_title);
            contentValues.put(TODO_DESC,todo_desc);
            contentValues.put(TODO_DATE,todo_date);
            contentValues.put(TODO_TIME,todo_time);
            contentValues.put(TODO_STATUS,todo_status);
            contentValues.put(EVENT_ID,event_id);
            database.insert(Constants.config.TABLE_TODO, null, contentValues);
            database.setTransactionSuccessful();
            message = "TODO Details saved!";
        }catch (Exception e){
            e.printStackTrace();
            message = "Sorry, error: "+e;
        }finally {
            database.endTransaction();
        }
        return message;
    }

    public String update(int todo_id,String todo_title, String todo_desc, String todo_date, String todo_time, int todo_status,int event_id){
        SQLiteDatabase database = DBHelper.getHelper(context).getWritableDatabase();
        String message = null;
        try{
            database.beginTransactionNonExclusive();
            ContentValues contentValues = new ContentValues();
            contentValues.put(TODO_TITLE,todo_title);
            contentValues.put(TODO_DESC,todo_desc);
            contentValues.put(TODO_DATE,todo_date);
            contentValues.put(TODO_TIME,todo_time);
            contentValues.put(TODO_STATUS,todo_status);
            contentValues.put(EVENT_ID,event_id);
            database.update(Constants.config.TABLE_TODO,  contentValues, TODO_ID+" = "+todo_id, null);
            database.setTransactionSuccessful();
            message = "TODO updated!";
        }catch (Exception e){
            e.printStackTrace();
            message = "Sorry, error: "+e;
        }finally {
            database.endTransaction();
        }

        return message;
    }

    public String updateStatus(int todo_id,int todo_status){
        SQLiteDatabase database = DBHelper.getHelper(context).getWritableDatabase();
        String message = null;
        try{
            database.beginTransactionNonExclusive();
            ContentValues contentValues = new ContentValues();
            contentValues.put(TODO_STATUS,todo_status);
            database.update(Constants.config.TABLE_TODO,  contentValues, TODO_ID+" = "+todo_id, null);
            database.setTransactionSuccessful();
            message = "TODO updated!";
        }catch (Exception e){
            e.printStackTrace();
            message = "Sorry, error: "+e;
        }finally {
            database.endTransaction();
        }

        return message;
    }
}
