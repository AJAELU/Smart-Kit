package com.example.john.eventplanner.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.john.eventplanner.R;
import com.example.john.eventplanner.core.DateTime;
import com.example.john.eventplanner.core.TimeAgo;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
/**
 * Created by john on 1/16/19.
 */
public class ListAdapter extends BaseAdapter {
    private Context context;
    private List<String> title, desc, date, address;
    private LayoutInflater inflter;
    public ListAdapter(Context applicationContext, List<String> title, List<String> desc, List<String> date, List<String> address) {
        this.context = applicationContext;
        this.title = title;
        this.desc = desc;
        this.date = date;
        this.address = address;
        inflter = (LayoutInflater.from(applicationContext));

    }
    @Override
    public int getCount() {
        return title.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {

        view = inflter.inflate(R.layout.event_list_item, null);
        TextView title_text = (TextView) view.findViewById(R.id.title_text);
        TextView desc_text = (TextView) view.findViewById(R.id.desc_text);
        TextView status_text = (TextView) view.findViewById(R.id.status_text);
        TextView left_text = (TextView) view.findViewById(R.id.left_text);
        TextView date_text = (TextView) view.findViewById(R.id.date_text);
        title_text.setText(title.get(i));
        desc_text.setText(desc.get(i));
        date_text.setText(date.get(i));
        status_text.setText(address.get(i));

        try{
            DateFormat dfm = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            //long TIMESTAMP = dfm.parse(date.get(i)).getTime();
            //String timeAgo = TimeAgo.getTimeAgo(TIMESTAMP);
            String daysLeft = DateTime.daysLeft(date.get(i));
            left_text.setText(daysLeft);

        }catch (Exception e){
            e.printStackTrace();
        }
        return view;
    }
}
