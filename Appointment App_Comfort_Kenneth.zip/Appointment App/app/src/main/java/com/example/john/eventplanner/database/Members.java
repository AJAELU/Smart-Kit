package com.example.john.eventplanner.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.example.john.eventplanner.core.Constants;
import com.example.john.eventplanner.core.DBHelper;

import static com.example.john.eventplanner.core.Constants.config.EVENT_ID;
import static com.example.john.eventplanner.core.Constants.config.MEMBER_ADDRESS;
import static com.example.john.eventplanner.core.Constants.config.MEMBER_EMAIL;
import static com.example.john.eventplanner.core.Constants.config.MEMBER_GENDER;
import static com.example.john.eventplanner.core.Constants.config.MEMBER_ID;
import static com.example.john.eventplanner.core.Constants.config.MEMBER_NAME;
import static com.example.john.eventplanner.core.Constants.config.MEMBER_PHONE;
import static com.example.john.eventplanner.core.Constants.config.MEMBER_ROLE;
import static com.example.john.eventplanner.core.Constants.config.MEMBER_STATUS;

/**
 * Created by john on 2/18/19.
 */

public class Members {
    private Context context;
    private static final String TAG = "User";
    public Members(Context context){
        this.context = context;
    }

    public String save(String member_name, String member_phone, String member_email, String member_address, String member_gender, String member_role, int member_status, int event_id){
        SQLiteDatabase database = DBHelper.getHelper(context).getWritableDatabase();
        String message = null;
        try{
            database.beginTransactionNonExclusive();
            ContentValues contentValues = new ContentValues();
            contentValues.put(MEMBER_NAME,member_name);
            contentValues.put(MEMBER_PHONE,member_phone);
            contentValues.put(MEMBER_EMAIL,member_email);
            contentValues.put(MEMBER_ADDRESS,member_address);
            contentValues.put(MEMBER_GENDER,member_gender);
            contentValues.put(MEMBER_ROLE,member_role);
            contentValues.put(MEMBER_STATUS,member_status);
            contentValues.put(EVENT_ID,event_id);
            database.insert(Constants.config.TABLE_MEMBER, null, contentValues);
            database.setTransactionSuccessful();
            message = "Member Details saved!";
        }catch (Exception e){
            e.printStackTrace();
            message = "Sorry, error: "+e;
        }finally {
            database.endTransaction();
        }
        return message;
    }

    public String update(int member_id,String member_name, String member_phone, String member_email, String member_address, String member_gender, String member_role, int member_status, int event_id){
        SQLiteDatabase database = DBHelper.getHelper(context).getWritableDatabase();
        String message = null;
        try{
            database.beginTransactionNonExclusive();
            ContentValues contentValues = new ContentValues();
            contentValues.put(MEMBER_NAME,member_name);
            contentValues.put(MEMBER_PHONE,member_phone);
            contentValues.put(MEMBER_EMAIL,member_email);
            contentValues.put(MEMBER_ADDRESS,member_address);
            contentValues.put(MEMBER_GENDER,member_gender);
            contentValues.put(MEMBER_ROLE,member_role);
            contentValues.put(MEMBER_STATUS,member_status);
            contentValues.put(EVENT_ID,event_id);
            database.update(Constants.config.TABLE_MEMBER,  contentValues, MEMBER_ID+" = "+member_id, null);
            database.setTransactionSuccessful();
            message = "Member updated!";
        }catch (Exception e){
            e.printStackTrace();
            message = "Sorry, error: "+e;
        }finally {
            database.endTransaction();
        }

        return message;
    }

    public String updateStatus(int member_id,int member_status){
        SQLiteDatabase database = DBHelper.getHelper(context).getWritableDatabase();
        String message = null;
        try{
            database.beginTransactionNonExclusive();
            ContentValues contentValues = new ContentValues();
            contentValues.put(MEMBER_STATUS,member_status);
            database.update(Constants.config.TABLE_MEMBER,  contentValues, MEMBER_ID+" = "+member_id, null);
            database.setTransactionSuccessful();
            message = "Member updated!";
        }catch (Exception e){
            e.printStackTrace();
            message = "Sorry, error: "+e;
        }finally {
            database.endTransaction();
        }

        return message;
    }
}
