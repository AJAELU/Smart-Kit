package com.example.john.eventplanner.core.security;

import android.content.Context;
import android.content.Intent;

import java.util.HashMap;

import static com.example.john.eventplanner.core.Constants.config.EVENT_ADDRESS;
import static com.example.john.eventplanner.core.Constants.config.EVENT_DATE;
import static com.example.john.eventplanner.core.Constants.config.EVENT_DESCRIPTIONS;
import static com.example.john.eventplanner.core.Constants.config.EVENT_ID;
import static com.example.john.eventplanner.core.Constants.config.EVENT_TITLE;

/**
 * Created by john on 3/16/18.
 */

public class UsersSession {
    private Context context;
    public String title,desc,date, address;
    int event_id;
    public UsersSession(Context context){
        this.context = context;
        SessionManager session = new SessionManager(context);
        //session.checkLogin();
        // get user data from session
        HashMap<String, String> user = session.getUserDetails();
        title = user.get(EVENT_TITLE);
        desc = user.get(EVENT_DESCRIPTIONS);
        date = user.get(EVENT_DATE);
        address = user.get(EVENT_ADDRESS);
        event_id = Integer.parseInt(user.get(EVENT_ID));
    }

    public int getEvent_id() {
        return event_id;
    }

    public String getAddress() {
        return address;
    }

    public String getDate() {
        return date;
    }

    public String getDesc() {
        return desc;
    }

    public String getTitle() {
        return title;
    }
}
