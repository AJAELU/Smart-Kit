package com.example.john.eventplanner.core;

/**
 * Created by john on 7/8/17.
 */

public class Constants {
    public abstract class config{
        public static final String URL_LOCALHOST = "http://127.0.0.1/events_planner/";
        public static final String URL_PHONE = "http://192.168.43.18/events_planner/";
        public static final String URL_MODERM = "http://10.127.110.253/events_planner/";
        public static final String URL_CAMTECH = "http://192.168.2.145/events_planner/";
        public static final String URL_SIMCENTER = "http://137.63.164.44/events_planner/";
        public static final String URL_STUDENT = "http://10.11.1.129/events_planner/";
        public static final String URL_SERVER = "http://173.255.219.164/events_planner/";
        public static final String HOST_URL = URL_CAMTECH+"mobile/";

        public static final String DATABASE_NAME = "event_db";
        public static final int DATABASE_VERSION = 1;

        public static final String TABLE_EVENT = "event_tb";
        public static final String EVENT_ID = "event_id";
        public static final String EVENT_TITLE = "event_title";
        public static final String EVENT_DESCRIPTIONS = "event_descriptions";
        public static final String EVENT_DATE = "event_date";
        public static final String EVENT_ADDRESS = "event_address";
        public static final String EVENT_STATUS = "event_status";

        public static final String TABLE_GUEST = "guest_tb";
        public static final String GUEST_ID = "guest_id";
        public static final String GUEST_NAME = "guest_name";
        public static final String GUEST_PHONE = "guest_phone";
        public static final String GUEST_EMAIL = "guest_email";
        public static final String GUEST_ADDRESS = "guest_address";
        public static final String GUEST_GENDER = "guest_gender";
        public static final String GUEST_TYPE = "guest_type";
        public static final String GUEST_STATUS = "guest_status";

        public static final String TABLE_ACCOUNT = "account_tb";
        public static final String ACCOUNT_ID = "account_id";
        public static final String ACCOUNT_NAME = "account_name";
        public static final String ACCOUNT_DATE = "account_date";
        public static final String ACCOUNT_TIME = "account_time";
        public static final String ACCOUNT_AMOUNT = "account_amount";
        public static final String ACCOUNT_TYPE = "account_type";
        public static final String ACCOUNT_STATUS = "account_status";
        public static final String ACCOUNT_DESCRIPTION = "account_descriptions";

        public static final String TABLE_INVITATION = "invitation_tb";
        public static final String INVITATION_ID = "invitation_id";
        public static final String INVITATION_DATE = "invitation_date";
        public static final String INVITATION_TIME = "invitation_time";
        public static final String INVITATION_STATUS = "invitation_status";

        public static final String TABLE_SHOPPING = "shopping_tb";
        public static final String SHOPPING_ID = "shopping_id";
        public static final String SHOPPING_NAME = "shopping_name";
        public static final String SHOPPING_DESCRIPTION = "shopping_description";
        public static final String SHOPPING_DATE = "shopping_date";
        public static final String SHOPPING_TIME = "shopping_time";
        public static final String SHOPPING_AMOUNT = "shopping_amount";
        public static final String SHOPPING_STATUS = "shopping_status";

        public static final String TABLE_MEMBER = "member_tb";
        public static final String MEMBER_ID = "member_id";
        public static final String MEMBER_NAME = "member_name";
        public static final String MEMBER_PHONE = "member_phone";
        public static final String MEMBER_EMAIL = "member_email";
        public static final String MEMBER_ADDRESS = "member_address";
        public static final String MEMBER_GENDER = "member_gender";
        public static final String MEMBER_ROLE = "member_role";
        public static final String MEMBER_STATUS = "member_status";

        public static final String TABLE_TODO = "todo_tb";
        public static final String TODO_ID = "todo_id";
        public static final String TODO_TITLE = "todo_title";
        public static final String TODO_DESC = "todo_desc";
        public static final String TODO_DATE = "todo_date";
        public static final String TODO_TIME = "todo_time";
        public static final String TODO_STATUS = "todo_status";


        public static final String HOUR = "time_hour";
        public static final String MINUTE = "time_minute";
        public static final String TIME_PICKER = "time_picker";
    }


}
