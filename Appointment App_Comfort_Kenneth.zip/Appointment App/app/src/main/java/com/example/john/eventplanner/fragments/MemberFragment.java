package com.example.john.eventplanner.fragments;

import android.content.Context;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.john.eventplanner.R;
import com.example.john.eventplanner.adapters.ContentLists;
import com.example.john.eventplanner.core.ReturnCusor;
import com.example.john.eventplanner.core.security.UsersSession;
import com.example.john.eventplanner.database.Guests;
import com.example.john.eventplanner.database.Members;

import java.util.ArrayList;
import java.util.List;

import static com.example.john.eventplanner.core.Constants.config.GUEST_ADDRESS;
import static com.example.john.eventplanner.core.Constants.config.GUEST_EMAIL;
import static com.example.john.eventplanner.core.Constants.config.GUEST_ID;
import static com.example.john.eventplanner.core.Constants.config.GUEST_NAME;
import static com.example.john.eventplanner.core.Constants.config.GUEST_PHONE;
import static com.example.john.eventplanner.core.Constants.config.GUEST_STATUS;
import static com.example.john.eventplanner.core.Constants.config.MEMBER_ADDRESS;
import static com.example.john.eventplanner.core.Constants.config.MEMBER_EMAIL;
import static com.example.john.eventplanner.core.Constants.config.MEMBER_ID;
import static com.example.john.eventplanner.core.Constants.config.MEMBER_NAME;
import static com.example.john.eventplanner.core.Constants.config.MEMBER_PHONE;
import static com.example.john.eventplanner.core.Constants.config.MEMBER_ROLE;
import static com.example.john.eventplanner.core.Constants.config.TABLE_GUEST;
import static com.example.john.eventplanner.core.Constants.config.TABLE_MEMBER;

/**
 * Created by john on 2/20/19.
 */

public class MemberFragment extends Fragment {
    /**
     * The fragment argument representing the section number for this
     * fragment.
     */
    private static final String ARG_SECTION_NUMBER = "section_number";

    private Context context;
    private ListView listView;
    private String gender = "";
    public MemberFragment() {
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
    }

    /**
     * Returns a new instance of this fragment for the given section
     * number.
     */
    public static MemberFragment newInstance(int sectionNumber) {
        MemberFragment fragment = new MemberFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_SECTION_NUMBER, sectionNumber);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_pager, container, false);
        TextView textView = (TextView) rootView.findViewById(R.id.section_label);
        textView.setText(getString(R.string.member));
        LinearLayout list_layout = (LinearLayout) rootView.findViewById(R.id.list_layout);
        list_layout.setBackgroundResource(R.drawable.team_bg);
        listView = (ListView) rootView.findViewById(R.id.listView);
        Button button = (Button) rootView.findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog();
            }
        });

        setHasOptionsMenu(true);

        setItems();
        return rootView;
    }

    private void setItems(){
        final List<String> name = new ArrayList<>();
        final List<Integer> ids = new ArrayList<>();
        final List<String> address = new ArrayList<>();
        final List<String> phone = new ArrayList<>();
        final List<String> email = new ArrayList<>();
        final List<String> type = new ArrayList<>();
        try{
            int status = 0;
            String query = "SELECT * FROM "+TABLE_MEMBER;
            Cursor cursor = ReturnCusor.cursor(query, context);
            if (cursor.moveToFirst()){
                do {
                    ids.add(cursor.getInt(cursor.getColumnIndex(MEMBER_ID)));
                    name.add(cursor.getString(cursor.getColumnIndex(MEMBER_NAME)));
                    address.add(cursor.getString(cursor.getColumnIndex(MEMBER_ADDRESS)));
                    phone.add(cursor.getString(cursor.getColumnIndex(MEMBER_PHONE)));
                    email.add(cursor.getString(cursor.getColumnIndex(MEMBER_EMAIL)));
                    type.add(cursor.getString(cursor.getColumnIndex(MEMBER_ROLE)));
                }while (cursor.moveToNext());
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        ContentLists adapter = new ContentLists(context,name,address,phone,email,type);
        listView.setAdapter(adapter);
    }

    private void showDialog(){
        AlertDialog.Builder alert = new AlertDialog.Builder(context);
        LayoutInflater inflater = getLayoutInflater();
        final View view = inflater.inflate(R.layout.add_guest, null);
        // this is set the view from XML inside AlertDialog
        alert.setView(view);
        // disallow cancel of AlertDialog on click of back button and outside touch
        final EditText input_name =  (EditText) view.findViewById(R.id.input_name);
        final EditText input_contact =  (EditText) view.findViewById(R.id.input_contact);
        final EditText input_email =  (EditText) view.findViewById(R.id.input_email);
        final EditText input_address =  (EditText) view.findViewById(R.id.input_address);
        final RadioGroup gender_group =  (RadioGroup) view.findViewById(R.id.gender_group);

        final RadioButton radio_male =  (RadioButton) view.findViewById(R.id.radio_male);
        final RadioButton radio_female =  (RadioButton) view.findViewById(R.id.radio_female);

        TextView header_text = (TextView) view.findViewById(R.id.header_text);
        header_text.setText(getString(R.string.add_member));
        final Spinner spinner =  (Spinner) view.findViewById(R.id.spinner);
        setSpinner(spinner);
        Button submit_btn = (Button) view.findViewById(R.id.submit_btn);
        submit_btn.setText(getString(R.string.add_member));

        radio_female.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b){
                    gender = "Female";
                }
            }
        });
        radio_male.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b){
                    gender = "Male";
                }
            }
        });

        final AlertDialog dialog = alert.create();
        //show dialog
        dialog.show();
        dialog.setCanceledOnTouchOutside(true);
        submit_btn.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
                //todo:::
                String name = input_name.getText().toString().trim();
                String contact = input_contact.getText().toString().trim();
                String email = input_email.getText().toString().trim();
                String address = input_address.getText().toString().trim();
                String type = spinner.getSelectedItem().toString();
                if(!name.equals("") && !contact.equals("") && !email.equals("") && !address.equals("") && !type.equals("SELECT TYPE---"))
                {
                    String message = new Members(context).save(name,contact,email,address,gender,type,1,new UsersSession(context).getEvent_id());
                    //String message = new ME(context).save(name,contact,email,address,gender,type,1, new UsersSession(context).getEvent_id());
                    setItems();
                    Toast.makeText(context, "Feedback: "+message, Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                }else {
                    Toast.makeText(context, "Invalid input", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.action_add:
                showDialog();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void setSpinner(Spinner spinner){
        List<String> list = new ArrayList<>();
        list.add("SELECT ROLE---");
        list.add("Others");

        ArrayAdapter<String> dataAdapter5 = new ArrayAdapter<String>(context,
                android.R.layout.simple_spinner_item, list);
        dataAdapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter5);
    }


}