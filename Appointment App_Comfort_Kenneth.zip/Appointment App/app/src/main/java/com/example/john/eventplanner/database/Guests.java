package com.example.john.eventplanner.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.example.john.eventplanner.core.Constants;
import com.example.john.eventplanner.core.DBHelper;

import static com.example.john.eventplanner.core.Constants.config.ACCOUNT_AMOUNT;
import static com.example.john.eventplanner.core.Constants.config.ACCOUNT_DATE;
import static com.example.john.eventplanner.core.Constants.config.ACCOUNT_DESCRIPTION;
import static com.example.john.eventplanner.core.Constants.config.ACCOUNT_ID;
import static com.example.john.eventplanner.core.Constants.config.ACCOUNT_NAME;
import static com.example.john.eventplanner.core.Constants.config.ACCOUNT_STATUS;
import static com.example.john.eventplanner.core.Constants.config.ACCOUNT_TIME;
import static com.example.john.eventplanner.core.Constants.config.ACCOUNT_TYPE;
import static com.example.john.eventplanner.core.Constants.config.EVENT_ID;
import static com.example.john.eventplanner.core.Constants.config.GUEST_ADDRESS;
import static com.example.john.eventplanner.core.Constants.config.GUEST_EMAIL;
import static com.example.john.eventplanner.core.Constants.config.GUEST_GENDER;
import static com.example.john.eventplanner.core.Constants.config.GUEST_ID;
import static com.example.john.eventplanner.core.Constants.config.GUEST_NAME;
import static com.example.john.eventplanner.core.Constants.config.GUEST_PHONE;
import static com.example.john.eventplanner.core.Constants.config.GUEST_STATUS;
import static com.example.john.eventplanner.core.Constants.config.GUEST_TYPE;

/**
 * Created by john on 2/18/19.
 */

public class Guests {
    private Context context;
    private static final String TAG = "User";
    public Guests(Context context){
        this.context = context;
    }

    public String save(String guest_name, String guest_phone, String guest_email, String guest_address, String guest_gender, String guest_type, int account_status, int event_id){
        SQLiteDatabase database = DBHelper.getHelper(context).getWritableDatabase();
        String message = null;
        try{
            database.beginTransactionNonExclusive();
            ContentValues contentValues = new ContentValues();
            contentValues.put(GUEST_NAME,guest_name);
            contentValues.put(GUEST_PHONE,guest_phone);
            contentValues.put(GUEST_EMAIL,guest_email);
            contentValues.put(GUEST_ADDRESS,guest_address);
            contentValues.put(GUEST_GENDER,guest_gender);
            contentValues.put(GUEST_TYPE,guest_type);
            contentValues.put(GUEST_STATUS,account_status);
            contentValues.put(EVENT_ID,event_id);
            database.insert(Constants.config.TABLE_GUEST, null, contentValues);
            database.setTransactionSuccessful();
            message = "Guest Details saved!";
        }catch (Exception e){
            e.printStackTrace();
            message = "Sorry, error: "+e;
        }finally {
            database.endTransaction();
        }
        return message;
    }

    public String update(int guest_id,String guest_name, String guest_phone, String guest_email, String guest_address, String guest_gender, String guest_type, int guest_status, int event_id){
        SQLiteDatabase database = DBHelper.getHelper(context).getWritableDatabase();
        String message = null;
        try{
            database.beginTransactionNonExclusive();
            ContentValues contentValues = new ContentValues();
            contentValues.put(GUEST_NAME,guest_name);
            contentValues.put(GUEST_PHONE,guest_phone);
            contentValues.put(GUEST_EMAIL,guest_email);
            contentValues.put(GUEST_ADDRESS,guest_address);
            contentValues.put(GUEST_GENDER,guest_gender);
            contentValues.put(GUEST_TYPE,guest_type);
            contentValues.put(GUEST_STATUS,guest_status);
            contentValues.put(EVENT_ID,event_id);
            database.update(Constants.config.TABLE_GUEST,  contentValues, GUEST_ID+" = "+guest_id, null);
            database.setTransactionSuccessful();
            message = "Guest updated!";
        }catch (Exception e){
            e.printStackTrace();
            message = "Sorry, error: "+e;
        }finally {
            database.endTransaction();
        }

        return message;
    }

    public String updateStatus(int guest_id,int guest_status){
        SQLiteDatabase database = DBHelper.getHelper(context).getWritableDatabase();
        String message = null;
        try{
            database.beginTransactionNonExclusive();
            ContentValues contentValues = new ContentValues();
            contentValues.put(GUEST_STATUS,guest_status);
            database.update(Constants.config.TABLE_GUEST,  contentValues, GUEST_ID+" = "+guest_id, null);
            database.setTransactionSuccessful();
            message = "Guest updated!";
        }catch (Exception e){
            e.printStackTrace();
            message = "Sorry, error: "+e;
        }finally {
            database.endTransaction();
        }

        return message;
    }
}
