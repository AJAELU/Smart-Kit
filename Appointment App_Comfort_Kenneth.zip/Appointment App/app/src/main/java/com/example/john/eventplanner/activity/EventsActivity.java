package com.example.john.eventplanner.activity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.john.eventplanner.R;
import com.example.john.eventplanner.adapters.ListAdapter;
import com.example.john.eventplanner.core.Constants;
import com.example.john.eventplanner.core.ReturnCusor;
import com.example.john.eventplanner.core.security.SessionManager;
import com.example.john.eventplanner.database.Events;
import com.example.john.eventplanner.database.Todo;
import com.example.john.eventplanner.receiver.AlarmReceiver;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.example.john.eventplanner.core.Constants.config.EVENT_ADDRESS;
import static com.example.john.eventplanner.core.Constants.config.EVENT_DATE;
import static com.example.john.eventplanner.core.Constants.config.EVENT_DESCRIPTIONS;
import static com.example.john.eventplanner.core.Constants.config.EVENT_ID;
import static com.example.john.eventplanner.core.Constants.config.EVENT_STATUS;
import static com.example.john.eventplanner.core.Constants.config.EVENT_TITLE;
import static com.example.john.eventplanner.core.Constants.config.TABLE_EVENT;

/**
 * Created by john on 2/19/19.
 */

public class EventsActivity extends AppCompatActivity {
    private FloatingActionButton fab;
    private Context context = this;
    private ListAdapter adapter;
    private ImageView sign_icon;
    private CollapsingToolbarLayout toolbar_layout;
    private ListView listView;
    private static int timeHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
    private static int timeMinute = Calendar.getInstance().get(Calendar.MINUTE);
    AlarmManager alarmManager;
    private PendingIntent pendingIntent;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event);
        fab = (FloatingActionButton) findViewById(R.id.fab);
        Toolbar toolbar = (Toolbar) findViewById(R.id.detail_toolbar);
        setSupportActionBar(toolbar);
        toolbar_layout = (CollapsingToolbarLayout) findViewById(R.id.toolbar_layout);
        listView = (ListView) findViewById(R.id.listView);
        sign_icon = (ImageView) findViewById(R.id.sign_icon);
        toolbar_layout.setTitle(getString(R.string.events_list));
        setItems();

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog();
            }
        });
        if (new SessionManager(context).isLoggedIn()){
            startActivity(new Intent(context, MainActivity.class));
            finish();
        }
        //new SessionManager(context).checkLogin();

        alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        Intent myIntent = new Intent(context, AlarmReceiver.class);
        pendingIntent = PendingIntent.getBroadcast(context, 0, myIntent, 0);
    }

    private void setItems(){
        final List<String> title = new ArrayList<>();
        final List<Integer> ids = new ArrayList<>();
        final List<String> desc = new ArrayList<>();
        final List<String> date_time = new ArrayList<>();
        final List<String> address = new ArrayList<>();
        try{
            int status = 0;
            String query = "SELECT * FROM "+TABLE_EVENT;
            Cursor cursor = ReturnCusor.cursor(query, context);
            if (cursor.moveToFirst()){
                do {
                    ids.add(cursor.getInt(cursor.getColumnIndex(EVENT_ID)));
                    title.add(cursor.getString(cursor.getColumnIndex(EVENT_TITLE)));
                    desc.add(cursor.getString(cursor.getColumnIndex(EVENT_DESCRIPTIONS)));
                    date_time.add(cursor.getString(cursor.getColumnIndex(EVENT_DATE)));
                    address.add(cursor.getString(cursor.getColumnIndex(EVENT_ADDRESS)));
                }while (cursor.moveToNext());
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        adapter = new ListAdapter(context,title,desc,date_time,address);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                new SessionManager(context).createLoginSession(ids.get(i),title.get(i),desc.get(i),date_time.get(i),address.get(i));
                startActivity(new Intent(context,MainActivity.class));
                finish();
            }
        });
    }
    private void showDialog(){
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        final View view = inflater.inflate(R.layout.add_event_layout, null);
        // this is set the view from XML inside AlertDialog
        alert.setView(view);
        // disallow cancel of AlertDialog on click of back button and outside touch
        final EditText input_title =  (EditText) view.findViewById(R.id.input_title);
        final EditText input_address =  (EditText) view.findViewById(R.id.input_address);
        final DatePicker datePicker =  (DatePicker) view.findViewById(R.id.datePicker);
        final TimePicker tp_timepicker = (TimePicker) view.findViewById(R.id.tp_timepicker);

        final EditText input_detail =  (EditText) view.findViewById(R.id.input_detail);
        Button submit_btn = (Button) view.findViewById(R.id.submit_btn);
        final AlertDialog dialog = alert.create();
        //show dialog
        dialog.show();
        dialog.setCanceledOnTouchOutside(true);
        submit_btn.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
                //todo:::
                String title = input_title.getText().toString().trim();
                String address = input_address.getText().toString().trim();
                int day = datePicker.getDayOfMonth(); // get the selected day of the month
                int month = datePicker.getMonth()+1; // get the selected month
                int year = datePicker.getYear(); // get the selected year
                int hr = tp_timepicker.getHour();
                int min = tp_timepicker.getMinute();
                String date = year+"-"+month+"-"+day+" "+hr+":"+min;
                String detail = input_detail.getText().toString().trim();
                if (!title.equals("") && !detail.equals("") && !date.equals("") && !address.equals("")){
                    String message = new Events(context).save(title,detail,date,address);
                    Toast.makeText(context,"Feedback: "+message, Toast.LENGTH_SHORT).show();
                    setItems();

                    timeHour = hr;
                    timeMinute = min;
                    //textView1.setText(timeHour + ":" + timeMinute);
                    setAlarm(year,month,day);

                    dialog.dismiss();
                }else {
                    Toast.makeText(context,"Invalid input", Toast.LENGTH_SHORT).show();
                }


            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //inflater.inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void setAlarm(int year,int month, int date){
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month);
        calendar.set(Calendar.DATE, date);
        calendar.set(Calendar.HOUR_OF_DAY, timeHour);
        calendar.set(Calendar.MINUTE, timeMinute);
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
    }
    private void cancelAlarm() {
        if (alarmManager!= null) {
            alarmManager.cancel(pendingIntent);
        }
    }
}
