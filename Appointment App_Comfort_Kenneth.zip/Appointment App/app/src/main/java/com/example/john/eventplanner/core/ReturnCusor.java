package com.example.john.eventplanner.core;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/**
 * Created by john on 8/28/18.
 */

public class ReturnCusor {
    public static Cursor cursor(String query, Context context){
        SQLiteDatabase db = DBHelper.getHelper(context).getReadableDatabase();
        Cursor cursor = db.rawQuery(query,null);
        return cursor;
    }
}
