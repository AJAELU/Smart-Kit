package com.example.john.eventplanner.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.john.eventplanner.R;
import com.example.john.eventplanner.core.DateTime;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

/**
 * Created by john on 2/20/19.
 */

public class ContentLists extends BaseAdapter {
    private Context context;
    private List<String> name, address, phone, email, type;
    private LayoutInflater inflter;
    public ContentLists(Context applicationContext, List<String> name, List<String> address, List<String> phone, List<String> email, List<String> type ) {
        this.context = applicationContext;
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.email = email;
        this.type = type;
        inflter = (LayoutInflater.from(applicationContext));

    }
    @Override
    public int getCount() {
        return name.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {

        view = inflter.inflate(R.layout.guest_content_item, null);

        TextView name_text = (TextView) view.findViewById(R.id.name_text);
        TextView address_text = (TextView) view.findViewById(R.id.address_text);
        TextView phone_text = (TextView) view.findViewById(R.id.phone_text);
        TextView email_text = (TextView) view.findViewById(R.id.email_text);
        TextView type_text = (TextView) view.findViewById(R.id.type_text);
        name_text.setText(name.get(i));
        address_text.setText(address.get(i));
        phone_text.setText(phone.get(i));
        email_text.setText(email.get(i));
        type_text.setText(type.get(i));
        return view;
    }
}
