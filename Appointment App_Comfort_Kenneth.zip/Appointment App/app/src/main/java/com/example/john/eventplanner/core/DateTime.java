package com.example.john.eventplanner.core;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by john on 7/9/17.
 */

public class DateTime {
    public static String getCurrentDate(){
        Calendar c = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String strDate = sdf.format(c.getTime());
        return strDate;
    }
    public static String getCurrentTime(){
        Calendar c = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        String strTime = sdf.format(c.getTime());
        return strTime;
    }
    public static int getCurrentDay(){
        String daysArray[] = {"Sunday","Monday","Tuesday", "Wednesday","Thursday","Friday", "Saturday"};
        Calendar calendar = Calendar.getInstance();
        int day = calendar.get(Calendar.DAY_OF_WEEK);
        return day;
    }

    public static boolean compareDate(String date){
        try{
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date strDate = sdf.parse(date);
            if (new Date().before(strDate)) {
                return true;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return false;
    }
    public static String timeAgo(String dateTime){
        String ago = "unknown";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            Date date=sdf.parse(dateTime);
            TimeAgo timeAgo = new TimeAgo();
           // ago = timeAgo.getTimeAgo(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return ago;
    }

    public static int getDate_By(String date){
        int day = 0;
        if (date.equals("Sunday")){
            day = 1;
        }else if (date.equals("Monday")){
            day = 2;
        }
        else if (date.equals("Tuesday")){
            day = 3;
        }
        else if (date.equals("Wednesday")){
            day = 4;
        }
        else if (date.equals("Thursday")){
            day = 5;
        }
        else if (date.equals("Friday")){
            day = 6;
        }
        else if (date.equals("Saturday")){
            day = 7;
        }
        return day;
    }

    public static String daysLeft(String date_time){
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat(
                    "yyyy-MM-dd HH:mm");
            // Please here set your event date//YYYY-MM-DD
            Date futureDate = dateFormat.parse(date_time);
            Date currentDate = new Date();
            if (!currentDate.after(futureDate)) {
                DateFormat dfm = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                long TIMESTAMP = dfm.parse(date_time).getTime();
                String timeLeft = TimeAgo.getTimeLeft(TIMESTAMP);
                return timeLeft;
            } else {
                DateFormat dfm = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                long TIMESTAMP = dfm.parse(date_time).getTime();
                String timeAgo = TimeAgo.getTimeAgo(TIMESTAMP);
                return timeAgo;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }
}
