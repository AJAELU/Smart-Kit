package com.example.john.eventplanner.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.example.john.eventplanner.core.Constants;
import com.example.john.eventplanner.core.DBHelper;

import static com.example.john.eventplanner.core.Constants.config.EVENT_ID;
import static com.example.john.eventplanner.core.Constants.config.GUEST_ID;
import static com.example.john.eventplanner.core.Constants.config.INVITATION_DATE;
import static com.example.john.eventplanner.core.Constants.config.INVITATION_ID;
import static com.example.john.eventplanner.core.Constants.config.INVITATION_STATUS;
import static com.example.john.eventplanner.core.Constants.config.INVITATION_TIME;
import static com.example.john.eventplanner.core.Constants.config.MEMBER_ADDRESS;
import static com.example.john.eventplanner.core.Constants.config.MEMBER_EMAIL;
import static com.example.john.eventplanner.core.Constants.config.MEMBER_GENDER;
import static com.example.john.eventplanner.core.Constants.config.MEMBER_ID;
import static com.example.john.eventplanner.core.Constants.config.MEMBER_NAME;
import static com.example.john.eventplanner.core.Constants.config.MEMBER_PHONE;
import static com.example.john.eventplanner.core.Constants.config.MEMBER_ROLE;
import static com.example.john.eventplanner.core.Constants.config.MEMBER_STATUS;

/**
 * Created by john on 2/18/19.
 */

public class Invitation {
    private Context context;
    private static final String TAG = "User";
    public Invitation(Context context){
        this.context = context;
    }

    public String save(String invitation_date, String invitation_time, int invitation_status,  int guest_id){
        SQLiteDatabase database = DBHelper.getHelper(context).getWritableDatabase();
        String message = null;
        try{
            database.beginTransactionNonExclusive();
            ContentValues contentValues = new ContentValues();
            contentValues.put(INVITATION_DATE,invitation_date);
            contentValues.put(INVITATION_TIME,invitation_time);
            contentValues.put(INVITATION_STATUS,invitation_status);
            contentValues.put(GUEST_ID,guest_id);
            database.insert(Constants.config.TABLE_INVITATION, null, contentValues);
            database.setTransactionSuccessful();
            message = "Invitation Details saved!";
        }catch (Exception e){
            e.printStackTrace();
            message = "Sorry, error: "+e;
        }finally {
            database.endTransaction();
        }
        return message;
    }

    public String update(int invitation_id,String invitation_date, String invitation_time, int invitation_status,  int guest_id){
        SQLiteDatabase database = DBHelper.getHelper(context).getWritableDatabase();
        String message = null;
        try{
            database.beginTransactionNonExclusive();
            ContentValues contentValues = new ContentValues();
            contentValues.put(INVITATION_DATE,invitation_date);
            contentValues.put(INVITATION_TIME,invitation_time);
            contentValues.put(INVITATION_STATUS,invitation_status);
            contentValues.put(GUEST_ID,guest_id);
            database.update(Constants.config.TABLE_INVITATION,  contentValues, INVITATION_ID+" = "+invitation_id, null);
            database.setTransactionSuccessful();
            message = "Invitation updated!";
        }catch (Exception e){
            e.printStackTrace();
            message = "Sorry, error: "+e;
        }finally {
            database.endTransaction();
        }

        return message;
    }

    public String updateStatus(int invitation_id,int invitation_status){
        SQLiteDatabase database = DBHelper.getHelper(context).getWritableDatabase();
        String message = null;
        try{
            database.beginTransactionNonExclusive();
            ContentValues contentValues = new ContentValues();
            contentValues.put(INVITATION_STATUS,invitation_status);
            database.update(Constants.config.TABLE_INVITATION,  contentValues, INVITATION_ID+" = "+invitation_id, null);
            database.setTransactionSuccessful();
            message = "Invitation updated!";
        }catch (Exception e){
            e.printStackTrace();
            message = "Sorry, error: "+e;
        }finally {
            database.endTransaction();
        }

        return message;
    }
}
