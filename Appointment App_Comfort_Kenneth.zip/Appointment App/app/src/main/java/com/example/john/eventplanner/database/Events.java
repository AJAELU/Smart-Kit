package com.example.john.eventplanner.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.example.john.eventplanner.core.Constants;
import com.example.john.eventplanner.core.DBHelper;

import static com.example.john.eventplanner.core.Constants.config.EVENT_ADDRESS;
import static com.example.john.eventplanner.core.Constants.config.EVENT_DATE;
import static com.example.john.eventplanner.core.Constants.config.EVENT_DESCRIPTIONS;
import static com.example.john.eventplanner.core.Constants.config.EVENT_ID;
import static com.example.john.eventplanner.core.Constants.config.EVENT_STATUS;
import static com.example.john.eventplanner.core.Constants.config.EVENT_TITLE;

/**
 * Created by john on 2/18/19.
 */

public class Events {
    private Context context;
    private static final String TAG = "User";
    public Events(Context context){
        this.context = context;
    }

    public String save(String event_title, String event_descriptions, String event_date, String event_address){
        SQLiteDatabase database = DBHelper.getHelper(context).getWritableDatabase();
        String message = null;
        try{
            database.beginTransactionNonExclusive();
            ContentValues contentValues = new ContentValues();
            contentValues.put(EVENT_TITLE,event_title);
            contentValues.put(EVENT_DESCRIPTIONS,event_descriptions);
            contentValues.put(EVENT_DATE,event_date);
            contentValues.put(EVENT_ADDRESS,event_address);
            database.insert(Constants.config.TABLE_EVENT, null, contentValues);
            database.setTransactionSuccessful();
            message = "Event Details saved!";

        }catch (Exception e){
            e.printStackTrace();
            message = "Sorry, error: "+e;
        }finally {
            database.endTransaction();
        }
        return message;
    }

    public String update(int event_id,String event_title, String event_descriptions, String event_date, String event_address,int event_status){
        SQLiteDatabase database = DBHelper.getHelper(context).getWritableDatabase();
        String message = null;
        try{
            database.beginTransactionNonExclusive();
            ContentValues contentValues = new ContentValues();
            contentValues.put(EVENT_STATUS,event_status);
            contentValues.put(EVENT_TITLE,event_title);
            contentValues.put(EVENT_DESCRIPTIONS,event_descriptions);
            contentValues.put(EVENT_DATE,event_date);
            contentValues.put(EVENT_ADDRESS,event_address);
            database.update(Constants.config.TABLE_EVENT,  contentValues, EVENT_ID+" = "+event_id, null);
            database.setTransactionSuccessful();
            message = "Event updated!";
        }catch (Exception e){
            e.printStackTrace();
            message = "Sorry, error: "+e;
        }finally {
            database.endTransaction();
        }

        return message;
    }

    public String updateStatus(int event_id,int event_status){
        SQLiteDatabase database = DBHelper.getHelper(context).getWritableDatabase();
        String message = null;
        try{
            database.beginTransactionNonExclusive();
            ContentValues contentValues = new ContentValues();
            contentValues.put(EVENT_STATUS,event_status);
            database.update(Constants.config.TABLE_EVENT,  contentValues, EVENT_ID+" = "+event_id, null);
            database.setTransactionSuccessful();
            message = "Event updated!";
        }catch (Exception e){
            e.printStackTrace();
            message = "Sorry, error: "+e;
        }finally {
            database.endTransaction();
        }

        return message;
    }
}
