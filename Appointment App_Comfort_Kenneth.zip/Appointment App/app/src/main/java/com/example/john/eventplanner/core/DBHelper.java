package com.example.john.eventplanner.core;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Handler;
import android.util.Log;

import static com.example.john.eventplanner.core.CreateTable.config.CREATE_ACCOUNT;
import static com.example.john.eventplanner.core.CreateTable.config.CREATE_EVENT;
import static com.example.john.eventplanner.core.CreateTable.config.CREATE_GUEST;
import static com.example.john.eventplanner.core.CreateTable.config.CREATE_INVITATION;
import static com.example.john.eventplanner.core.CreateTable.config.CREATE_MEMBER;
import static com.example.john.eventplanner.core.CreateTable.config.CREATE_SHOPPING;
import static com.example.john.eventplanner.core.CreateTable.config.CREATE_TODO;

public class DBHelper extends SQLiteOpenHelper {
    private final Handler handler;
    // queries to create the table
    private static DBHelper instance;
    public static synchronized DBHelper getHelper(Context context)
    {
        if (instance == null)
            instance = new DBHelper(context);
        return instance;
    }
    public DBHelper(Context context) {
        super(context, Constants.config.DATABASE_NAME, null, Constants.config.DATABASE_VERSION);
        handler = new Handler(context.getMainLooper());
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_EVENT);
        db.execSQL(CREATE_MEMBER);
        db.execSQL(CREATE_GUEST);
        db.execSQL(CREATE_INVITATION);
        db.execSQL(CREATE_SHOPPING);
        db.execSQL(CREATE_ACCOUNT);
        db.execSQL(CREATE_TODO);
        Log.e("DATABASE OPERATION","Data base created / open successfully");

    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+ Constants.config.TABLE_EVENT);
        db.execSQL("DROP TABLE IF EXISTS "+ Constants.config.TABLE_MEMBER);
        db.execSQL("DROP TABLE IF EXISTS "+ Constants.config.TABLE_GUEST);
        db.execSQL("DROP TABLE IF EXISTS "+ Constants.config.TABLE_INVITATION);
        db.execSQL("DROP TABLE IF EXISTS "+ Constants.config.TABLE_SHOPPING);
        db.execSQL("DROP TABLE IF EXISTS "+ Constants.config.TABLE_ACCOUNT);
        db.execSQL("DROP TABLE IF EXISTS "+ Constants.config.TABLE_TODO);
        onCreate(db);
        Log.e("DATABASE OPERATION", "Table created / open successfully");

    }
}